package com.example.musicdbgui.model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import static com.example.musicdbgui.model.DataSourceValues.*;

public class DataSource {
    private Connection connection;
    private PreparedStatement insertIntoArtists;
    private PreparedStatement insertIntoAlbums;
    private PreparedStatement insertIntoSongs;
    private PreparedStatement queryArtist;
    private PreparedStatement queryAlbum;
    private PreparedStatement queryViewSongTitleInfoView;
    private PreparedStatement queryAlbumsByArtistId;
    private PreparedStatement queryArtistBySongId;
    private PreparedStatement queryArtistBySongTitle;
    private PreparedStatement queryMaxAlbumTrack;
    private PreparedStatement updateArtistName;
    private PreparedStatement updateAlbumName;
    private PreparedStatement updateSongTitle;

    private static final DataSource instance = new DataSource();

    public static DataSource getInstance(){return instance;}


    public boolean open(){
        try {
            connection = DriverManager.getConnection(CONNECTION_STRING);
            queryViewSongTitleInfoView = connection.prepareStatement(QUERY_VIEW_SONG_TITLE_INFO_PREP_STMT);
            insertIntoArtists = connection.prepareStatement(INSERT_ARTIST, Statement.RETURN_GENERATED_KEYS);
            insertIntoAlbums = connection.prepareStatement(INSERT_ALBUMS, Statement.RETURN_GENERATED_KEYS);
            insertIntoSongs = connection.prepareStatement(INSERT_SONGS);
            queryArtist = connection.prepareStatement(QUERY_ARTIST);
            queryAlbum = connection.prepareStatement(QUERY_ALBUM);
            queryAlbumsByArtistId = connection.prepareStatement(QUERY_ALBUMS_BY_ARTIST_ID);
            queryArtistBySongId = connection.prepareStatement(QUERY_ARTIST_BY_SONG_ID);
            queryArtistBySongTitle = connection.prepareStatement(QUERY_ARTIST_BY_SONG_TITLE);
            queryMaxAlbumTrack = connection.prepareStatement(QUERY_MAX_ALBUM_TRACK);
            updateArtistName = connection.prepareStatement(UPDATE_ARTIST_NAME);
            updateAlbumName = connection.prepareStatement(UPDATE_ALBUM_NAME);
            updateSongTitle = connection.prepareStatement(UPDATE_SONG_TITLE);
            return true;
        }catch (SQLException e){
            return false;
        }
    }

    public void close(){
        try {
            if (queryViewSongTitleInfoView != null){
                queryViewSongTitleInfoView.close();
            }

            if (insertIntoArtists != null){
                insertIntoArtists.close();
            }

            if (insertIntoAlbums != null){
                insertIntoAlbums.close();
            }

            if (insertIntoSongs != null){
                insertIntoSongs.close();
            }

            if (queryArtist != null){
                queryArtist.close();
            }

            if (queryAlbum != null){
                queryAlbum.close();
            }

            if(queryAlbumsByArtistId != null){
                queryAlbumsByArtistId.close();
            }

            if (queryArtistBySongId != null){
                queryArtistBySongId.close();
            }

            if (queryArtistBySongTitle != null){
                queryArtistBySongTitle.close();
            }

            if (queryMaxAlbumTrack != null){
                queryMaxAlbumTrack.close();
            }

            if (updateArtistName != null){
                updateArtistName.close();
            }

            if(updateAlbumName != null){
                updateAlbumName.close();
            }

            if (connection != null){
                connection.close();
            }
        }catch (SQLException ignored){

        }
    }

    public List<Artist> queryTheArtists(int orderOfSort){
        StringBuilder queryString = new StringBuilder(QUERY_ARTIST_START_STRING);

        appendOrderString(orderOfSort, queryString, QUERY_ARTIST_SORT_STRING);
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(queryString.toString())){

            List<Artist> artists = new ArrayList<>();
            while (resultSet.next()){
                Artist artist = new Artist();
                artist.setId(resultSet.getInt(INDEX_ARTIST_ID));
                artist.setName(resultSet.getString(INDEX_ALBUM_NAME));
                artists.add(artist);
            }
            return artists;

        }catch (SQLException e){
            return null;
        }
    }

    public List<Album> queryTheAlbums(int orderOfSort){
        StringBuilder queryString = new StringBuilder(QUERY_ALBUM_START_STRING);
        appendOrderString(orderOfSort, queryString, QUERY_ALBUM_SORT_STRING);

        try (Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(queryString.toString())){

            List<Album> albums = new ArrayList<>();
            while (resultSet.next()){
                Album album = new Album();
                album.setId(resultSet.getInt(INDEX_ALBUM_ID));
                album.setName(resultSet.getString(INDEX_ALBUM_NAME));
                album.setArtist(resultSet.getInt(INDEX_ALBUM_ARTIST));
                albums.add(album);
            }
            return albums;

        }catch (SQLException e){
            return null;
        }
    }

    public List<Song> queryTheSongs(int orderOfSort){
        StringBuilder queryString = new StringBuilder(QUERY_SONG_START_STRING);
        appendOrderString(orderOfSort, queryString, QUERY_SONG_SORT_STRING);

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(queryString.toString())){

            List<Song> songs = new ArrayList<>();
            while (resultSet.next()){
                Song song = new Song();
                song.setId(resultSet.getInt(INDEX_SONG_ID));
                song.setTrack(resultSet.getInt(INDEX_SONG_TRACK));
                song.setTitle(resultSet.getString(INDEX_SONG_TITLE));
                song.setAlbum(resultSet.getInt(INDEX_SONG_ALBUM));
                songs.add(song);
            }
            return songs;

        }catch (SQLException e){
            return null;
        }
    }

    public List<Album> queryTheAlbumForArtistId(int id){
        try{
            queryAlbumsByArtistId.setInt(1, id);
            ResultSet resultSet = queryAlbumsByArtistId.executeQuery();

            List<Album> albums = new ArrayList<>();
            while (resultSet.next()){
                Album album = new Album();
                album.setId(resultSet.getInt(1));
                album.setName(resultSet.getString(2));
                album.setArtist(resultSet.getInt(3));
                albums.add(album);
            }
            return albums;
        }catch (SQLException e){
            return null;
        }
    }

    public Artist queryTheArtisForSongId(int id){
        try {
            queryArtistBySongId.setInt(1, id);
            ResultSet resultSet = queryArtistBySongId.executeQuery();
            Artist artist = new Artist();
            if (resultSet.next()){
                artist.setId(resultSet.getInt(INDEX_ARTIST_ID));
                artist.setName(resultSet.getString(INDEX_ARTIST_NAME));
            }
            return artist;
        }catch (SQLException e){
            return null;
        }
    }

    public List<Artist> queryTheArtistsForSongTitle(String title){
        try {
            queryArtistBySongTitle.setString(1, '%' + title + '%');
            ResultSet resultSet = queryArtistBySongTitle.executeQuery();
            List<Artist> artists = new ArrayList<>();
            while (resultSet.next()){
                Artist artist = new Artist();
                artist.setId(resultSet.getInt(INDEX_ARTIST_ID));
                artist.setName(resultSet.getString(INDEX_ARTIST_NAME));
                artists.add(artist);
            }
            return artists;
        }catch (SQLException e){
            return null;
        }
    }

    public int getCount(String tableName){
        String queryString = "SELECT COUNT(*) FROM " + tableName;
        try (Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(queryString)){
            return resultSet.getInt(1);
        }catch (SQLException e){
            return -1;
        }
    }

    public void createTheViewForSongArtists(){
        try (Statement statement = connection.createStatement()){
            statement.execute(CREATE_ARTIST_FOR_SONG_VIEW);
        }catch (SQLException ignored){
        }
    }

    public List<ArtistSong> queryTheSongInfoView(String songTitle){

        try {
            queryViewSongTitleInfoView.setString(1,'%' + songTitle + '%');
            ResultSet resultSet = queryViewSongTitleInfoView.executeQuery();

            List<ArtistSong> artistSongs = new ArrayList<>();
            while (resultSet.next()){
                ArtistSong artistSong = new ArtistSong();
                artistSong.setArtistName(resultSet.getString(1));
                artistSong.setAlbumName(resultSet.getString(2));
                artistSong.setTrack(resultSet.getInt(3));
                artistSong.setTitle(resultSet.getString(4));
                artistSongs.add(artistSong);
            }
            return artistSongs;
        }catch (SQLException e){
            return null;
        }
    }

    private void appendOrderString(int orderOfSort, StringBuilder queryString, String sortInitialString){
        if (orderOfSort != NO_ORDER){
            queryString.append(sortInitialString);
            if (orderOfSort == ASC_ORDER){
                queryString.append("ASC");
            }else {
                queryString.append("DESC");
            }
        }
    }

    private int insertTheArtists(String name) throws SQLException{
        queryArtist.setString(1, name);
        ResultSet resultSet = queryArtist.executeQuery();

        if (resultSet.next()){
            return resultSet.getInt(1);
        }else {
            insertIntoArtists.setString(1,name);
            int nrAffectedRows = insertIntoArtists.executeUpdate();

            if (nrAffectedRows != 1){
                throw new SQLException("Couldn't insert the artist");
            }
            ResultSet generatedKeys = insertIntoArtists.getGeneratedKeys();
            if (generatedKeys.next()){
                return generatedKeys.getInt(1);
            }else {
                throw new SQLException("Couldn't get id for artist " + name);
            }
        }
    }

    public boolean updateArtistName(int id, String newName){
        try {
            updateArtistName.setString(1, newName);
            updateArtistName.setInt(2, id);
            return updateArtistName.executeUpdate() == 1;
        }catch (SQLException e){
            return false;
        }
    }

    public boolean updateAlbumName(int id, String newName){
        try {
            updateAlbumName.setString(1, newName);
            updateAlbumName.setInt(2, id);
            return updateAlbumName.executeUpdate() == 1;
        }catch (SQLException e){
            return false;
        }
    }

    public boolean updateSongTitle(int id, String newTitle){
        try {
            updateSongTitle.setString(1, newTitle);
            updateSongTitle.setInt(2, id);
            return updateSongTitle.executeUpdate() == 1;
        }catch (SQLException e){
            return false;
        }
    }


    private int insertTheAlbum(String albumName, int artistId) throws SQLException{
        queryAlbum.setString(1, albumName);
        queryAlbum.setInt(2,artistId);
        ResultSet resultSet = queryAlbum.executeQuery();

        if (resultSet.next()){
            return resultSet.getInt(1);
        }else {
            insertIntoAlbums.setString(1, albumName);
            insertIntoAlbums.setInt(2, artistId);

            int nrAffectedRows = insertIntoAlbums.executeUpdate();
            if (nrAffectedRows != 1){
                throw new SQLException("Couldn't insert the album " +albumName);
            }
            ResultSet generatedKeys = insertIntoAlbums.getGeneratedKeys();
            if (generatedKeys.next()){
                return generatedKeys.getInt(1);
            }else {
                throw new SQLException("Couldn't get id for album " + albumName);
            }
        }
    }

    public boolean insertTheSong(String songTitle, String artistName, String albumName) {
        try {
            connection.setAutoCommit(false);
            int artistId = insertTheArtists(artistName);
            int albumId = insertTheAlbum(albumName, artistId);
            int trackNumber = findMaxAlbumTrack(albumId);
            if (trackNumber != -1){
                insertIntoSongs.setInt(1, trackNumber+1);
            }else {
                return false;
            }
            insertIntoSongs.setString(2, songTitle);
            insertIntoSongs.setInt(3, albumId);

            int nrAffectedRows = insertIntoSongs.executeUpdate();
            if (nrAffectedRows == 1){
                connection.commit();
                return true;
            }else {
                return false;
            }

        }catch (Exception e){
            try {
                connection.rollback();
            }catch (SQLException ignored){
            }
            return false;
        }finally {
            try {
                connection.setAutoCommit(true);
            }catch (SQLException ignored){
            }
        }
    }

    private int findMaxAlbumTrack(int albumId){
        try {
            queryMaxAlbumTrack.setInt(1, albumId);
            ResultSet resultSet = queryMaxAlbumTrack.executeQuery();
            if (resultSet.next()){
                return resultSet.getInt(1);
            }
            return 0;
        }catch (SQLException e){
            return -1;
        }
    }

}

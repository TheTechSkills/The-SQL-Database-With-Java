package com.example.musicdbgui.model;

public final class DataSourceValues {
    public static final String DB_NAME = "sound.db";
    public static final String CONNECTION_STRING ="jdbc:sqlite:G:\\Developing\\SQL Database With Java\\Programs\\JDBC With Graphical User Interface Java Program\\Course\\MusicDBGUI\\" + DB_NAME;

    public static final String TABLE_ALBUMS = "albums";
    public static final String COLUMN_ALBUM_ID ="_id";
    public static final String COLUMN_ALBUM_NAME = "name";
    public static final String COLUMN_ALBUM_ARTIST = "artist";

    public static final int INDEX_ALBUM_ID = 1;
    public static final int INDEX_ALBUM_NAME = 2;
    public static final int INDEX_ALBUM_ARTIST = 3;

    public static final String TABLE_ARTISTS = "artists";
    public static final String COLUMN_ARTISTS_ID= "_id";
    public static final String COLUMN_ARTISTS_NAME = "name";

    public static final int INDEX_ARTIST_ID = 1;
    public static final int INDEX_ARTIST_NAME = 2;

    public static final String TABLE_SONGS ="songs";
    public static final String COLUMN_SONG_ID="_id";
    public static final String COLUMN_SONG_TRACK ="track";
    public static final String COLUMN_SONG_TITLE = "title";
    public static final String COLUMN_SONG_ALBUM="album";

    public static final int INDEX_SONG_ID = 1;
    public static final int INDEX_SONG_TRACK = 2;
    public static final int INDEX_SONG_TITLE = 3;
    public static final int INDEX_SONG_ALBUM = 4;

    public static final int NO_ORDER = 0;
    public static final int ASC_ORDER = 1;
    public static final int DESC_ORDER = 2;

    public static final String TABLE_ARTISTS_SONG_VIEW = "artist_list";
    public static final String CREATE_ARTIST_FOR_SONG_VIEW = "CREATE VIEW IF NOT EXISTS " +
            TABLE_ARTISTS_SONG_VIEW + " AS SELECT " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_NAME + ", " +
            TABLE_ALBUMS + '.' + COLUMN_ALBUM_NAME + " AS " + COLUMN_SONG_ALBUM + ", " + TABLE_SONGS +
            '.' + COLUMN_SONG_TRACK + ", " + TABLE_SONGS + '.' + COLUMN_SONG_TITLE +
            " FROM " + TABLE_SONGS +
            " INNER JOIN " +  TABLE_ALBUMS +  " ON " + TABLE_SONGS + '.' +
            COLUMN_SONG_ALBUM + " = " +TABLE_ALBUMS+  '.' + COLUMN_ALBUM_ID +
            " INNER JOIN " + TABLE_ARTISTS + " ON " +TABLE_ALBUMS+ '.' + COLUMN_ALBUM_ARTIST +
            " = " +TABLE_ARTISTS + '.' +COLUMN_ARTISTS_ID +
            " ORDER BY "+
            TABLE_ARTISTS + '.' + COLUMN_ARTISTS_NAME + ", "+
            TABLE_ALBUMS + '.' + COLUMN_ARTISTS_NAME + ", "+
            TABLE_SONGS + '.' + COLUMN_SONG_TRACK;

    public static final String QUERY_ARTIST_START_STRING ="SELECT * FROM " + TABLE_ARTISTS;
    public static final String QUERY_ARTIST_SORT_STRING = " ORDER BY " + TABLE_ARTISTS + '.' +COLUMN_ARTISTS_NAME + " COLLATE NOCASE ";
    public static final String QUERY_ALBUM_START_STRING = "SELECT * FROM " + TABLE_ALBUMS;
    public static final String QUERY_ALBUM_SORT_STRING = " ORDER BY " + TABLE_ALBUMS + '.' +COLUMN_ALBUM_NAME + " COLLATE NOCASE ";
    public static final String QUERY_SONG_START_STRING = "SELECT * FROM " + TABLE_SONGS;
    public static final String QUERY_SONG_SORT_STRING = " ORDER BY " + TABLE_SONGS + '.' +COLUMN_SONG_TITLE + " COLLATE NOCASE ";
    public static final String QUERY_VIEW_SONG_TITLE_INFO_PREP_STMT = "SELECT " + COLUMN_ARTISTS_NAME + ", "+
            COLUMN_SONG_ALBUM + ", " + COLUMN_SONG_TRACK + ", " + COLUMN_SONG_TITLE +
            " FROM " + TABLE_ARTISTS_SONG_VIEW + " WHERE " +
            COLUMN_SONG_TITLE + " LIKE ?";
    public static final String QUERY_ARTIST = "SELECT " + COLUMN_ARTISTS_ID + " FROM " +TABLE_ARTISTS +
            " WHERE " + COLUMN_ALBUM_NAME + " = ?";
    public static final String QUERY_ALBUM = "SELECT " + COLUMN_ALBUM_ID + " FROM " + TABLE_ALBUMS +
            " WHERE " + COLUMN_ALBUM_NAME + " = ?" + " AND " + COLUMN_ALBUM_ARTIST + " = ?";
    public static final String QUERY_ALBUMS_BY_ARTIST_ID = "SELECT * FROM " + TABLE_ALBUMS + " WHERE " +COLUMN_ALBUM_ARTIST +
            " = ? ORDER BY " + COLUMN_ARTISTS_NAME + " COLLATE NOCASE";
    public static final String QUERY_ARTIST_BY_SONG_ID = "SELECT " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_ID +
            ", " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_NAME +
            " FROM " + TABLE_SONGS + " INNER JOIN " + TABLE_ALBUMS + " ON " + TABLE_SONGS + '.' + COLUMN_SONG_ALBUM +
            " = "  + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ID + " INNER JOIN " + TABLE_ARTISTS + " ON " +TABLE_ARTISTS + '.' +
            COLUMN_ARTISTS_ID + " = " + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ARTIST + " WHERE " + TABLE_SONGS + '.' + COLUMN_SONG_ID +
            " = ?";
    public static final String QUERY_ARTIST_BY_SONG_TITLE = "SELECT DISTINCT " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_ID +
            ", " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_NAME +
            " FROM " + TABLE_SONGS + " INNER JOIN " + TABLE_ALBUMS + " ON " + TABLE_SONGS + '.' + COLUMN_SONG_ALBUM +
            " = "  + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ID + " INNER JOIN " + TABLE_ARTISTS + " ON " +TABLE_ARTISTS + '.' +
            COLUMN_ARTISTS_ID + " = " + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ARTIST + " WHERE " + TABLE_SONGS + '.' + COLUMN_SONG_TITLE +
            " LIKE ?";
    public static final String QUERY_MAX_ALBUM_TRACK = "SELECT MAX(" + COLUMN_SONG_TRACK + ") FROM " +TABLE_ARTISTS+
            " INNER JOIN " + TABLE_ALBUMS + " ON " + TABLE_ARTISTS + '.' + COLUMN_ARTISTS_ID + " = " + TABLE_ALBUMS +
            '.' + COLUMN_ALBUM_ARTIST + " INNER JOIN " + TABLE_SONGS + " ON " + TABLE_SONGS + '.' +COLUMN_SONG_ALBUM +
            " = " + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ID + " WHERE " + TABLE_ALBUMS + '.' + COLUMN_ALBUM_ID + " = ?";

    public static final String INSERT_ARTIST = "INSERT INTO " + TABLE_ARTISTS + '(' +
            COLUMN_ARTISTS_NAME + ')' + "VALUES(?)";
    public static final String INSERT_ALBUMS = "INSERT INTO " + TABLE_ALBUMS + '(' +
            COLUMN_ALBUM_NAME + ", " + COLUMN_ALBUM_ARTIST + ')' + "VALUES(?, ?)";
    public static final String INSERT_SONGS = "INSERT INTO " + TABLE_SONGS + '(' +
            COLUMN_SONG_TRACK + ", " + COLUMN_SONG_TITLE + ", " + COLUMN_SONG_ALBUM + ')' +
            "VALUES(?,?,?)";

    public static final String UPDATE_ARTIST_NAME = "UPDATE " +TABLE_ARTISTS + " SET " +COLUMN_ARTISTS_NAME +
            " = ? WHERE " + COLUMN_ARTISTS_ID + " = ?";
    public static final String UPDATE_ALBUM_NAME = "UPDATE " + TABLE_ALBUMS + " SET " + COLUMN_ALBUM_NAME +
            " = ? WHERE " + COLUMN_ALBUM_ID + "= ?";
    public static final String UPDATE_SONG_TITLE = "UPDATE " + TABLE_SONGS + " SET " + COLUMN_SONG_TITLE +
            " = ? WHERE " + COLUMN_SONG_ID + "= ?";
}

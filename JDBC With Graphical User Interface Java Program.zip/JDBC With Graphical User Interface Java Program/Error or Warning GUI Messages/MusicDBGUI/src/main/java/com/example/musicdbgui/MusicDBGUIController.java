package com.example.musicdbgui;

import com.example.musicdbgui.model.*;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import org.w3c.dom.Text;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

public class MusicDBGUIController<FontAwesomeIconView> implements Initializable {
    private static final String MUSIC_DB = "/musicdb/";
    private static final String ARTISTS ="artists";
    public static final String ALBUMS = "albums";
    public static final String SONGS = "songs";
    public static final String ALBUMS_ARTIST ="artist_albums";
    public static final String ARTIST_SONG ="song_artist";
    public static final String DETAIL_SONG ="song_details";

    @FXML
    private Button btnUpdateArtist;

    @FXML
    private Button btnUpdateAlbum;

    @FXML
    private Button btnUpdateSong;

    @FXML
    private Button btnAddSong;

    @FXML
    private Button btnAlbums;

    @FXML
    private Button btnAlbumsArtists;

    @FXML
    private Button btnArtistSongs;

    @FXML
    private Button btnArtists;

    @FXML
    private Button btnDetailSongs;

    @FXML
    private FontAwesomeIconView btnFindArtist;

    @FXML
    private FontAwesomeIconView btnFindAlbum;

    @FXML
    private FontAwesomeIconView btnFindSong;

    @FXML
    private FontAwesomeIconView btnFindArtistSong;

    @FXML
    private FontAwesomeIconView btnFindSongDetail;

    @FXML
    private FontAwesomeIconView btnSearchAlbum;

    @FXML
    private FontAwesomeIconView btnSearchArtist;

    @FXML
    private FontAwesomeIconView btnSearchArtistSong;

    @FXML
    private FontAwesomeIconView btnSearchSong;

    @FXML
    private FontAwesomeIconView btnSearchSongDetail;

    @FXML
    private Button btnSongs;

    @FXML
    private Label lblStatusMax;

    @FXML
    private Label lblStatusMini;

    @FXML
    private Label lblArtistsCount;

    @FXML
    private Label lblAlbumsCount;

    @FXML
    private Label lblSongsCount;

    @FXML
    private Pane pnIStatus;

    @FXML
    private FontAwesomeIconView btnCloseApp;

    @FXML
    private GridPane pnAlbums;

    @FXML
    private GridPane pnAlbumsArtist;

    @FXML
    private GridPane pnArtistSong;

    @FXML
    private GridPane pnArtists;

    @FXML
    private GridPane pnSongDetail;

    @FXML
    private GridPane pnSongs;

    @FXML
    private ProgressBar progressBar;

    @FXML
    private TextField songDetailSearchBar;

    @FXML
    private TextField songDetailArtist;

    @FXML
    private TextField songDetailAlbum;

    @FXML
    private TextField artistSearchBar;

    @FXML
    private TextField albumSearchBar;

    @FXML
    private TextField songSearchBar;

    @FXML
    private TextField artistSongSearchBar;

    @FXML
    private TableView<Artist> artistsTable = new TableView<>();

    @FXML
    private TableView<Album> albumsTable = new TableView<>();

    @FXML
    private TableView<Song> songsTable = new TableView<>();

    @FXML
    private TableView<Album> albumsArtistTable = new TableView<>();

    @FXML
    private TableView<Artist> artistSongTable = new TableView<>();

    @FXML
    private TableView<ArtistSong> songDetailTable = new TableView<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void listTheArtists(){
        Task<ObservableList<Artist>> task = new GetAllArtistsTask();
        artistsTable.itemsProperty().bind(task.valueProperty());
        progressBar.progressProperty().bind(task.progressProperty());
        progressBar.setVisible(true);
        task.setOnCancelled(e->progressBar.setVisible(false));
        task.setOnSucceeded(e->progressBar.setVisible(false));
        task.setOnFailed(e->progressBar.setVisible(false));
        new Thread(task).start();
    }

    public void showArtistsCount(){
        new Thread(){
            @Override
            public void run() {
                super.run();
                lblArtistsCount.setText(new DecimalFormat("#,###").format(
                        DataSource.getInstance().getCount(DataSource.TABLE_ARTISTS))
                        + " recs");
            }
        }.start();
    }



    @FXML
    private void handleClicks(ActionEvent event){
        if (event.getSource() == btnArtists){
            lblStatusMini.setText((MUSIC_DB +""+ ARTISTS));
            lblStatusMax.setText("Artists");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(113,86,221), CornerRadii.EMPTY, Insets.EMPTY)));
            pnArtists.toFront();
            pnArtists.setVisible(true);
        }else if(event.getSource() == btnAlbums){
            lblStatusMini.setText((MUSIC_DB+""+ALBUMS));
            lblStatusMax.setText("Albums");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(43,63,99), CornerRadii.EMPTY, Insets.EMPTY)));
            pnAlbums.toFront();
            pnAlbums.setVisible(true);

            Task<ObservableList<Album>> task = new Task<ObservableList<Album>>() {
                @Override
                protected ObservableList<Album> call() throws Exception {
                    List<Album> albumList = DataSource.getInstance().queryTheAlbums(DataSource.ASC_ORDER);
                    if (albumList == null){
                        Platform.runLater(() ->{
                            MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Albums",
                                    "Ups! Something went wrong.", "Couldn't find albums");
                        });
                    }
                    return FXCollections.observableArrayList(albumList);
                }
            };

            albumsTable.itemsProperty().bind(task.valueProperty());
            progressBar.progressProperty().bind(task.progressProperty());
            progressBar.setVisible(true);
            task.setOnCancelled(e-> progressBar.setVisible(false));
            task.setOnSucceeded(e-> progressBar.setVisible(false));
            task.setOnFailed(e-> progressBar.setVisible(false));
            new Thread(task).start();

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    lblAlbumsCount.setText(new DecimalFormat("#,###").format(
                            DataSource.getInstance().getCount(DataSource.TABLE_ALBUMS )
                    )+ " recs");
                }
            });

        }else if(event.getSource() == btnSongs){
            lblStatusMini.setText((MUSIC_DB+""+SONGS));
            lblStatusMax.setText("Songs");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(43,99,63), CornerRadii.EMPTY, Insets.EMPTY)));
            pnSongs.toFront();
            pnSongs.setVisible(true);

            Task<ObservableList<Song>> task = new Task<ObservableList<Song>>() {
                @Override
                protected ObservableList<Song> call() throws Exception {
                    List<Song> songList = DataSource.getInstance().queryTheSongs(DataSource.ASC_ORDER);
                    if (songList == null){
                        Platform.runLater(() ->{
                            MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Songs",
                                    "Ups! Something went wrong.", "Couldn't find songs");
                        });
                    }
                    return FXCollections.observableArrayList(songList);
                }
            };

            songsTable.itemsProperty().bind(task.valueProperty());
            progressBar.progressProperty().bind(task.progressProperty());
            progressBar.setVisible(true);
            task.setOnCancelled(e-> progressBar.setVisible(false));
            task.setOnSucceeded(e-> progressBar.setVisible(false));
            task.setOnFailed(e-> progressBar.setVisible(false));
            new Thread(task).start();

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    lblSongsCount.setText(new DecimalFormat("#,###").format(
                            DataSource.getInstance().getCount(DataSource.TABLE_SONGS)
                    )+ " recs");
                }
            });

        }else if(event.getSource() == btnAlbumsArtists){
            lblStatusMini.setText((MUSIC_DB+""+ALBUMS_ARTIST));

            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(99,43,63), CornerRadii.EMPTY, Insets.EMPTY)));
            pnAlbumsArtist.toFront();
            pnArtists.setVisible(false);
            pnAlbums.setVisible(false);
            pnSongs.setVisible(false);
            pnArtistSong.setVisible(false);
            pnSongDetail.setVisible(false);

            Artist artist = artistsTable.getSelectionModel().getSelectedItem();
            if (artist == null){
                alertUIMessage(Alert.AlertType.WARNING, "Artists", "Select an artist",
                        "No artist selected");
                lblStatusMax.setText("Albums (artist)");
                return;
            }
            Task<ObservableList<Album>> task = new Task<ObservableList<Album>>() {
                @Override
                protected ObservableList<Album> call() throws Exception {
                    List<Album> albumList = DataSource.getInstance().queryTheAlbumForArtistId(DataSource.ASC_ORDER);
                    if (albumList == null){
                        Platform.runLater(() ->{
                            MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Albums",
                                    "Ups! Something went wrong.", "Couldn't find albums for artist");
                        });
                    }
                    return FXCollections.observableArrayList(albumList);
                }
            };

            albumsArtistTable.itemsProperty().bind(task.valueProperty());
            lblStatusMax.setText("Albums (" + artist.getName() + ")");
            new Thread(task).start();


        }else if(event.getSource() == btnArtistSongs){
            lblStatusMini.setText((MUSIC_DB+""+ARTIST_SONG));
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(42,28,66), CornerRadii.EMPTY, Insets.EMPTY)));

            pnArtistSong.toFront();
            pnArtistSong.setVisible(true);

            Song song = songsTable.getSelectionModel().getSelectedItem();
            if (song == null){
                lblStatusMax.setText("Artist (song)");
                return;
            }

            Task<ObservableList<Artist>> task = new Task<ObservableList<Artist>>() {
                @Override
                protected ObservableList<Artist> call() throws Exception {
                    Artist artist = DataSource.getInstance().queryTheArtisForSongId(song.getId());
                    if (artist == null){
                        Platform.runLater(() ->{
                            MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Artist",
                                    "Ups! Something went wrong.", "Couldn't find artist for song");
                        });
                    }
                    return FXCollections.observableArrayList(artist);
                }
            };
            artistSongTable.itemsProperty().bind(task.valueProperty());
            setLabelMax("Artist", song.getTitle());
            new Thread(task).start();

        }else if(event.getSource() == btnDetailSongs){
            lblStatusMini.setText((MUSIC_DB+""+DETAIL_SONG));
            lblStatusMax.setText("Details (song)");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(41,68,66), CornerRadii.EMPTY, Insets.EMPTY)));
            pnSongDetail.toFront();
            pnSongDetail.setVisible(true);
        }else if(event.getSource() == btnAddSong){
            String songTitle = songDetailSearchBar.getText();
            String artistName = songDetailArtist.getText();
            String albumName = songDetailAlbum.getText();

            if (isValidText(songTitle)){
                if (isValidText(artistName)){
                    if (isValidText(albumName)){
                        Task<Boolean> task = new Task<Boolean>() {
                            @Override
                            protected Boolean call() throws Exception {
                                if(DataSource.getInstance().insertTheSong(songTitle, artistName, albumName)){
                                    return true;
                                }
                                Platform.runLater(() ->{
                                    MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Song Insertion",
                                            "Ups! Something went wrong.", "Couldn't insert song");
                                });
                                return false;
                            }
                        };

                        task.setOnSucceeded(e ->{
                            if (task.valueProperty().get()){
                                success(songDetailSearchBar);
                                success(songDetailArtist);
                                success(songDetailAlbum);
                                songDetailSearchBar.setText("");
                                songDetailArtist.setText("");
                                songDetailAlbum.setText("");
                                findSongDetail(songTitle);
                            }
                        });
                        new Thread(task).start();
                    }else {
                        alert(songDetailAlbum);
                    }
                }else {
                    alert(songDetailArtist);
                }
            }else {
                alert(songDetailSearchBar);
            }
        }
    }

    @FXML
    private void handleUpdateClicks(ActionEvent event){
        if (event.getSource() == btnUpdateArtist){
            Artist artist = artistsTable.getSelectionModel().getSelectedItem();
            String newName = artistSearchBar.getText();
            if (isValidText(newName)){
                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return DataSource.getInstance().updateArtistName(artist.getId(), newName);
                    }
                };

                task.setOnSucceeded( e->{
                    if (task.valueProperty().get()){
                        artist.setName(newName);
                        artistsTable.refresh();
                        artistsTable.scrollTo(artist);
                        success(artistSearchBar);
                    }
                });

                new Thread(task).start();
            }else {
                alert(artistSearchBar);
            }
        }

        if (event.getSource() == btnUpdateAlbum){
            Album album = albumsTable.getSelectionModel().getSelectedItem();
            String newName = albumSearchBar.getText();
            if (isValidText(newName)) {
                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return DataSource.getInstance().updateAlbumName(album.getId(), newName);
                    }
                };

                task.setOnSucceeded(e ->{
                    if (task.valueProperty().get()){
                        album.setName(newName);
                        albumsTable.refresh();
                        albumsTable.scrollTo(album);
                        success(albumSearchBar);
                    }
                });
                new Thread(task).start();
            }else{
                alert(albumSearchBar);
            }

        }

        if (event.getSource() == btnUpdateSong){
            Song song = songsTable.getSelectionModel().getSelectedItem();
            String newTitle = songSearchBar.getText();
            if (isValidText(newTitle)){
                Task<Boolean> task = new Task<Boolean>() {
                    @Override
                    protected Boolean call() throws Exception {
                        return DataSource.getInstance().updateSongTitle(song.getId(), newTitle);
                    }
                };

                task.setOnSucceeded(e ->{
                    if (task.valueProperty().get()){
                        song.setTitle(newTitle);
                        songsTable.refresh();
                        songsTable.scrollTo(song);
                        success(songSearchBar);
                    }
                });
                new Thread(task).start();
            }else {
                alert(songSearchBar);
            }

        }
    }

    @FXML
    private void handleIconsClick(MouseEvent event){
        if (event.getSource() == btnFindArtist){
            artistsTable.getItems().stream().filter(item -> Objects.equals(item.getName(), artistSearchBar.getText()))
                    .findAny()
                    .ifPresent(item -> {
                        artistsTable.getSelectionModel().select(item);
                        artistsTable.scrollTo(item);
                    });
        }

        if (event.getSource() == btnFindAlbum){
            albumsTable.getItems().stream().filter(item -> Objects.equals(item.getName(), albumSearchBar.getText()))
                    .findAny()
                    .ifPresent(item -> {
                        albumsTable.getSelectionModel().select(item);
                        albumsTable.scrollTo(item);
                    });
        }

        if (event.getSource() == btnFindSong){
            songsTable.getItems().stream().filter(item -> Objects.equals(item.getTitle(), songSearchBar.getText()))
                    .findAny()
                    .ifPresent(item -> {
                        songsTable.getSelectionModel().select(item);
                        songsTable.scrollTo(item);
                    });
        }

        if (event.getSource() == btnFindArtistSong){
            Task<ObservableList<Artist>> task = new Task<ObservableList<Artist>>() {
                @Override
                protected ObservableList<Artist> call() throws Exception {
                    List<Artist> artistList = DataSource.getInstance().queryTheArtistsForSongTitle(artistSongSearchBar.getText());
                    if (artistList == null){
                        Platform.runLater(() ->{
                            MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Artist",
                                    "Ups! Something went wrong.", "Couldn't find Artist for song");
                        });
                    }
                    return FXCollections.observableArrayList(artistList);
                }
            };

            artistSongTable.itemsProperty().bind(task.valueProperty());
            setLabelMax("Artist", artistSongSearchBar.getText());
            new Thread(task).start();
        }

        if(event.getSource() == btnFindSongDetail){
            findSongDetail(songDetailSearchBar.getText());
        }

    }

    @FXML
    private void handleClose(MouseEvent event){
        if (event.getSource() == btnCloseApp){
            System.exit(0);
        }
    }

    private void setLabelMax(String menu, String song){
        if (song.length()>32){
            lblStatusMax.setText(menu + " (" + song.substring(0,32) + "...)");
        }else {
            lblStatusMax.setText(menu + " (" + song + ")");
        }
    }

    private void findSongDetail(String song){
        Task<ObservableList<ArtistSong>> task = new Task<ObservableList<ArtistSong>>() {
            @Override
            protected ObservableList<ArtistSong> call() throws Exception {
                List<ArtistSong> artistSongList = DataSource.getInstance().queryTheSongInfoView(song);
                if (artistSongList == null){
                    Platform.runLater(() ->{
                        MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Details",
                                "Ups! Something went wrong.", "Couldn't find details for song");
                    });
                }
                return FXCollections.observableArrayList(artistSongList);
            }
        };

        songDetailTable.itemsProperty().bind(task.valueProperty());
        progressBar.progressProperty().bind(task.progressProperty());
        progressBar.setVisible(true);
        task.setOnCancelled(e->progressBar.setVisible(false));
        task.setOnSucceeded(e->progressBar.setVisible(false));
        task.setOnFailed(e->progressBar.setVisible(false));
        setLabelMax("Details", song);
        new Thread(task).start();
    }

    public void createViewForSongArtists(){
        DataSource.getInstance().createTheViewForSongArtists();
    }

    private void alert(TextField textField){
        textField.setBorder(new Border(new BorderStroke(Color.rgb(226,110,110), BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, BorderWidths.DEFAULT)));
    }

    private void success(TextField textField){
        textField.setBorder(new Border(new BorderStroke(Color.rgb(0, 176, 24), BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, BorderWidths.DEFAULT)));
    }

    private boolean isValidText(String text){
        return text.trim().length() > 0;
    }

    public static void alertUIMessage(Alert.AlertType alertType, String title, String header, String content){
        Alert alert =  new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.show();
    }

}

class GetAllArtistsTask extends Task {
    @Override
    public ObservableList<Artist> call(){
        List<Artist> artistList = DataSource.getInstance().queryTheArtists(DataSource.ASC_ORDER);
        if (artistList == null){
            Platform.runLater(() ->{
                MusicDBGUIController.alertUIMessage(Alert.AlertType.ERROR, "Artists",
                        "Ups! Something went wrong.", "Couldn't find artists");
            });
        }
        return FXCollections.observableArrayList(artistList);
    }
}
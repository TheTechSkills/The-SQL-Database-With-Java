module com.example.musicdbgui {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.musicdbgui to javafx.fxml;
    exports com.example.musicdbgui;
}
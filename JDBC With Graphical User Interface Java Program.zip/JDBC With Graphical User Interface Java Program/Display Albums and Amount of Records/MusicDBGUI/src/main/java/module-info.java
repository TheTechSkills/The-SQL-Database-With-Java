module com.example.musicdbgui {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.musicdbgui to javafx.fxml;
    opens com.example.musicdbgui.model to javafx.fxml;

    exports com.example.musicdbgui;
    exports com.example.musicdbgui.model;
}
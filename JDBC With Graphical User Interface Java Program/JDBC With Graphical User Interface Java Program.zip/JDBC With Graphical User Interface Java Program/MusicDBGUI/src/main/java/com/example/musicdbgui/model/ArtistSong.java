package com.example.musicdbgui.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ArtistSong {
    private final SimpleStringProperty artistName;
    private final SimpleStringProperty albumName;
    private final SimpleIntegerProperty track;
    private final SimpleStringProperty title;

    public ArtistSong() {
        this.artistName = new SimpleStringProperty();
        this.albumName = new SimpleStringProperty();
        this.track = new SimpleIntegerProperty();
        this.title = new SimpleStringProperty();
    }

    public String getArtistName() {
        return artistName.get();
    }

    public void setArtistName(String artistName) {
        this.artistName.set(artistName);
    }

    public String getAlbumName() {
        return albumName.get();
    }

    public void setAlbumName(String albumName) {
        this.albumName.set(albumName);
    }

    public int getTrack() {
        return track.get();
    }

    public void setTrack(int track) {
        this.track.set(track);
    }

    public String getTitle() {
        return title.get();
    }

    public void setTitle(String title) {
        this.title.set(title);
    }
}

package com.example.musicdbgui.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ArtistSong {
    private SimpleStringProperty artistName;
    private SimpleStringProperty albumName;
    private SimpleIntegerProperty track;
    private SimpleStringProperty title;

    public ArtistSong() {
        this.artistName = new SimpleStringProperty();
        this.albumName = new SimpleStringProperty();
        this.track = new SimpleIntegerProperty();
        this.title = new SimpleStringProperty();
    }

    public String getArtistName() {
        return artistName.get();
    }

    public SimpleStringProperty artistNameProperty() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName.set(artistName);
    }

    public String getAlbumName() {
        return albumName.get();
    }

    public SimpleStringProperty albumNameProperty() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName.set(albumName);
    }

    public int getTrack() {
        return track.get();
    }

    public SimpleIntegerProperty trackProperty() {
        return track;
    }

    public void setTrack(int track) {
        this.track.set(track);
    }

    public String getTitle() {
        return title.get();
    }

    public SimpleStringProperty titleProperty() {
        return title;
    }

    public void setTitle(String title) {
        this.title.set(title);
    }
}

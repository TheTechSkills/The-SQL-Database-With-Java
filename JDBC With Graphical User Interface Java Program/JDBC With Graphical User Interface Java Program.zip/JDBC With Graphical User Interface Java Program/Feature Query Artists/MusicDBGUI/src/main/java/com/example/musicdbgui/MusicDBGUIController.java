package com.example.musicdbgui;

import com.example.musicdbgui.model.Album;
import com.example.musicdbgui.model.Artist;
import com.example.musicdbgui.model.DataSource;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.Objects;
import java.util.ResourceBundle;

public class MusicDBGUIController<FontAwesomeIconView> implements Initializable {
    private static final String MUSIC_DB = "/musicdb/";
    private static final String ARTISTS ="artists";
    public static final String ALBUMS = "albums";
    public static final String SONGS = "songs";
    public static final String ALBUMS_ARTIST ="artist_albums";
    public static final String ARTIST_SONG ="song_artist";
    public static final String DETAIL_SONG ="song_details";

    @FXML
    private Button btnAddAlbum;

    @FXML
    private Button btnAddArtist;

    @FXML
    private Button btnAddSong;

    @FXML
    private Button btnAlbums;

    @FXML
    private Button btnAlbumsArtists;

    @FXML
    private Button btnArtistSongs;

    @FXML
    private Button btnArtists;

    @FXML
    private Button btnDetailSongs;

    @FXML
    private FontAwesomeIconView btnFindArtist;

    @FXML
    private FontAwesomeIconView btnSearchAlbum;

    @FXML
    private FontAwesomeIconView btnSearchArtist;

    @FXML
    private FontAwesomeIconView btnSearchArtistSong;

    @FXML
    private FontAwesomeIconView btnSearchSong;

    @FXML
    private FontAwesomeIconView btnSearchSongDetail;

    @FXML
    private Button btnSongs;

    @FXML
    private Label lblStatusMax;

    @FXML
    private Label lblStatusMini;

    @FXML
    private Label lblArtistsCount;

    @FXML
    private Pane pnIStatus;

    @FXML
    private FontAwesomeIconView btnCloseApp;

    @FXML
    private GridPane pnAlbums;

    @FXML
    private GridPane pnAlbumsArtist;

    @FXML
    private GridPane pnArtistSong;

    @FXML
    private GridPane pnArtists;

    @FXML
    private GridPane pnSongDetail;

    @FXML
    private GridPane pnSongs;

    @FXML
    private TextField songDetailSearchBar;

    @FXML
    private TextField artistSearchBar;

    @FXML
    private TableView<Artist> artistsTable = new TableView<>();

    @FXML
    private TableView<Album> albumsArtistTable = new TableView<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void listTheArtists(){
        Task<ObservableList<Artist>> task = new GetAllArtistsTask();
        artistsTable.itemsProperty().bind(task.valueProperty());
        new Thread(task).start();
    }

    public void showArtistsCount(){
        new Thread(){
            @Override
            public void run() {
                super.run();
                lblArtistsCount.setText(new DecimalFormat("#,###").format(
                        DataSource.getInstance().getCount(DataSource.TABLE_ARTISTS))
                        + " rec");
            }
        }.start();
    }



    @FXML
    private void handleClicks(ActionEvent event){
        if (event.getSource() == btnArtists){
            lblStatusMini.setText((MUSIC_DB +""+ ARTISTS));
            lblStatusMax.setText("Artists");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(113,86,221), CornerRadii.EMPTY, Insets.EMPTY)));
            pnArtists.toFront();
        }else if(event.getSource() == btnAlbums){
            lblStatusMini.setText((MUSIC_DB+""+ALBUMS));
            lblStatusMax.setText("Albums");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(43,63,99), CornerRadii.EMPTY, Insets.EMPTY)));
            pnAlbums.toFront();
        }else if(event.getSource() == btnSongs){
            lblStatusMini.setText((MUSIC_DB+""+SONGS));
            lblStatusMax.setText("Songs");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(43,99,63), CornerRadii.EMPTY, Insets.EMPTY)));
            pnSongs.toFront();
        }else if(event.getSource() == btnAlbumsArtists){
            lblStatusMini.setText((MUSIC_DB+""+ALBUMS_ARTIST));

            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(99,43,63), CornerRadii.EMPTY, Insets.EMPTY)));
            pnAlbumsArtist.toFront();

            Artist artist = artistsTable.getSelectionModel().getSelectedItem();
            if (artist == null){
                System.out.println("No artist selected");
                lblStatusMax.setText("Albums (artist)");
                return;
            }
            Task<ObservableList<Album>> task = new Task<ObservableList<Album>>() {
                @Override
                protected ObservableList<Album> call() throws Exception {
                    return FXCollections.observableArrayList(
                            DataSource.getInstance().queryTheAlbumForArtistId(artist.getId())
                    );
                }
            };

            albumsArtistTable.itemsProperty().bind(task.valueProperty());
            lblStatusMax.setText("Albums (" + artist.getName() + ")");
            new Thread(task).start();


        }else if(event.getSource() == btnArtistSongs){
            lblStatusMini.setText((MUSIC_DB+""+ARTIST_SONG));
            lblStatusMax.setText("Artist (song)");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(42,28,66), CornerRadii.EMPTY, Insets.EMPTY)));
            pnArtistSong.toFront();
        }else if(event.getSource() == btnDetailSongs){
            lblStatusMini.setText((MUSIC_DB+""+DETAIL_SONG));
            lblStatusMax.setText("Details (song)");
            pnIStatus.setBackground(new Background(new BackgroundFill(Color.rgb(41,68,66), CornerRadii.EMPTY, Insets.EMPTY)));
            pnSongDetail.toFront();
        }
    }


    @FXML
    private void handleIconsClick(MouseEvent event){
        if (event.getSource() == btnFindArtist){
            artistsTable.getItems().stream().filter(item -> Objects.equals(item.getName(), artistSearchBar.getText()))
                    .findAny()
                    .ifPresent(item -> {
                        artistsTable.getSelectionModel().select(item);
                        artistsTable.scrollTo(item);
                    });
        }
    }

    @FXML
    private void handleClose(MouseEvent event){
        if (event.getSource() == btnCloseApp){
            System.exit(0);
        }
    }

}

class GetAllArtistsTask extends Task {
    @Override
    public ObservableList<Artist> call(){
        return FXCollections.observableArrayList(DataSource.getInstance().queryTheArtists(DataSource.ASC_ORDER));
    }
}